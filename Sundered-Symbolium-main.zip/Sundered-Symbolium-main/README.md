# Sundered-Symbolium
### RU
Тестовая версия большого мода, вдохновлённого [Экзогенезисом](https://github.com/AureusStratus/ExoGenesis).
### EN
Test version of a large mod inspired by [Exogenesis](https://github.com/AureusStratus/ExoGenesis).


